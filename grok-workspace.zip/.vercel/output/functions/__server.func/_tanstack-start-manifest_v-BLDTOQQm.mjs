//#region node_modules/.nitro/vite/services/ssr/assets/_tanstack-start-manifest_v-BLDTOQQm.js
var tsrStartManifest = () => ({ routes: {
	__root__: {
		filePath: "/workspace/src/routes/__root.tsx",
		children: [
			"/",
			"/join",
			"/login",
			"/me",
			"/meets",
			"/sell",
			"/listing/$id",
			"/api/auth/$"
		],
		preloads: [
			"/assets/index-BG0ELCpv.js",
			"/assets/react-DB-4Zxce.js",
			"/assets/preload-helper-BxisXxwp.js"
		],
		scripts: [{ attrs: {
			type: "module",
			async: !0,
			src: "/assets/index-BG0ELCpv.js"
		} }]
	},
	"/": {
		filePath: "/workspace/src/routes/index.tsx",
		children: void 0,
		preloads: [
			"/assets/routes-DYG84c5W.js",
			"/assets/ui-DtRyiIQi.js",
			"/assets/listing-card-C_lI_EjH.js"
		]
	},
	"/join": {
		filePath: "/workspace/src/routes/join.tsx",
		children: void 0,
		preloads: [
			"/assets/join-CcGPwaQG.js",
			"/assets/ui-DtRyiIQi.js",
			"/assets/profile-form-pJXb-W8e.js"
		]
	},
	"/login": {
		filePath: "/workspace/src/routes/login.tsx",
		children: void 0,
		preloads: [
			"/assets/login-BFGaEDUm.js",
			"/assets/ui-DtRyiIQi.js",
			"/assets/client-cLw6edTc.js"
		]
	},
	"/me": {
		filePath: "/workspace/src/routes/me.tsx",
		children: void 0,
		preloads: [
			"/assets/me-B1qMl8X2.js",
			"/assets/ui-DtRyiIQi.js",
			"/assets/listing-card-C_lI_EjH.js",
			"/assets/profile-form-pJXb-W8e.js"
		]
	},
	"/meets": {
		filePath: "/workspace/src/routes/meets.tsx",
		children: void 0,
		preloads: [
			"/assets/meets-tzQfQ-qy.js",
			"/assets/ui-DtRyiIQi.js",
			"/assets/meetup-card-DQhGrr2w.js"
		]
	},
	"/sell": {
		filePath: "/workspace/src/routes/sell.tsx",
		children: void 0,
		preloads: [
			"/assets/sell-CXDGLzPy.js",
			"/assets/ui-DtRyiIQi.js",
			"/assets/listing-form-DgePjG3d.js"
		]
	},
	"/listing/$id": {
		filePath: "/workspace/src/routes/listing.$id.tsx",
		children: void 0,
		preloads: [
			"/assets/listing._id-DOo0-Yjy.js",
			"/assets/ui-DtRyiIQi.js",
			"/assets/listing-card-C_lI_EjH.js",
			"/assets/listing-form-DgePjG3d.js",
			"/assets/meetup-card-DQhGrr2w.js"
		]
	}
} });
//#endregion
export { tsrStartManifest };
