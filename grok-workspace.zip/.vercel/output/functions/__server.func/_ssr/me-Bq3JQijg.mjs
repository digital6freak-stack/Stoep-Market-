import { o as __toESM } from "../_runtime.mjs";
import { Z as require_react, w as require_jsx_runtime } from "../_libs/@tanstack/react-router+[...].mjs";
import { l as formatWhen, s as errorText } from "./market-BYMNOAra.mjs";
import { a as MemberGate, c as SignOutButton, g as listMine, y as saveProfile } from "./ui-BhtY2CpM.mjs";
import { t as ProfileForm } from "./profile-form-CRJMDkjO.mjs";
import { n as ListingCardView } from "./listing-card-C3MFOFWY.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/me-Bq3JQijg.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
function MePage() {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(MemberGate, { children: (profile, refresh) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Stall, {
		profile,
		refresh
	}) });
}
function Stall({ profile, refresh }) {
	const [rows, setRows] = (0, import_react.useState)(null);
	const [error, setError] = (0, import_react.useState)(null);
	const [saved, setSaved] = (0, import_react.useState)(false);
	(0, import_react.useEffect)(() => {
		let live = true;
		listMine().then((next) => {
			if (live) setRows(next);
		}).catch((err) => {
			if (live) setError(errorText(err));
		});
		return () => {
			live = false;
		};
	}, [
		profile.displayName,
		profile.area,
		profile.bio
	]);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "mx-auto max-w-xl space-y-8",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "flex items-start justify-between gap-3",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
					className: "display-bold text-4xl text-ink",
					children: profile.displayName
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
					className: "mt-1 text-sm text-muted",
					children: [profile.area, formatWhen(profile.createdAt) ? ` · joined ${formatWhen(profile.createdAt)}` : ""]
				})] }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(SignOutButton, {})]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
				className: "space-y-3",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
						className: "display text-2xl text-ink",
						children: "Your details"
					}),
					saved ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "text-sm text-moss",
						children: "Saved."
					}) : null,
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(ProfileForm, {
						initial: {
							displayName: profile.displayName,
							area: profile.area,
							bio: profile.bio
						},
						submitLabel: "Save",
						onSubmit: async (draft) => {
							await saveProfile({ data: draft });
							setSaved(true);
							refresh();
						}
					})
				]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
				className: "space-y-3",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
						className: "display text-2xl text-ink",
						children: "Your posts"
					}),
					error ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "text-sm text-clay",
						children: error
					}) : null,
					rows === null ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "text-sm text-muted",
						children: "Loading your posts…"
					}) : rows.length === 0 ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "text-sm text-pretty text-muted",
						children: "You haven't put anything out yet."
					}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)("ul", {
						className: "grid gap-4",
						children: rows.map((listing) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("li", { children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ListingCardView, { listing }) }, listing.id))
					})
				]
			})
		]
	});
}
//#endregion
export { MePage as component };
