import { o as __toESM } from "../_runtime.mjs";
import { Z as require_react, w as require_jsx_runtime } from "../_libs/@tanstack/react-router+[...].mjs";
import { f as fieldClass, n as Button, r as Field, t as Alert } from "./ui-BhtY2CpM.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/profile-form-CRJMDkjO.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
function ProfileForm({ initial, submitLabel, onSubmit }) {
	const [draft, setDraft] = (0, import_react.useState)(initial);
	const [error, setError] = (0, import_react.useState)(null);
	const [busy, setBusy] = (0, import_react.useState)(false);
	async function handleSubmit(event) {
		event.preventDefault();
		setBusy(true);
		setError(null);
		try {
			await onSubmit(draft);
		} catch (err) {
			setError(err instanceof Error ? err.message : "Could not save that");
			setBusy(false);
		}
	}
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("form", {
		onSubmit: handleSubmit,
		className: "space-y-4",
		children: [
			error ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Alert, { children: error }) : null,
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
				label: "What should neighbours call you?",
				hint: "A first name is enough.",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
					className: fieldClass,
					value: draft.displayName,
					maxLength: 40,
					required: true,
					autoComplete: "nickname",
					onChange: (event) => setDraft({
						...draft,
						displayName: event.target.value
					})
				})
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
				label: "Your area",
				hint: "Where you can hand something over.",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
					className: fieldClass,
					value: draft.area,
					maxLength: 60,
					required: true,
					onChange: (event) => setDraft({
						...draft,
						area: event.target.value
					})
				})
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
				label: "A line about you",
				hint: "Optional. A landmark helps: near the park, the school, the taxi rank.",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("textarea", {
					className: `${fieldClass} min-h-24 py-3`,
					value: draft.bio,
					maxLength: 280,
					onChange: (event) => setDraft({
						...draft,
						bio: event.target.value
					})
				})
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
				type: "submit",
				disabled: busy,
				className: "w-full sm:w-auto",
				children: busy ? "Saving…" : submitLabel
			})
		]
	});
}
//#endregion
export { ProfileForm as t };
