import { b as Link, w as require_jsx_runtime } from "../_libs/@tanstack/react-router+[...].mjs";
import { c as formatPrice, l as formatWhen, u as meetupLabel } from "./market-BYMNOAra.mjs";
import { n as Button } from "./ui-BhtY2CpM.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/meetup-card-aRrQmQe4.js
var import_jsx_runtime = require_jsx_runtime();
function MeetupCard({ meetup, busy, onAccept, onDecline, onCancel }) {
	const other = meetup.role === "seller" ? meetup.buyerName : meetup.sellerName;
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("article", {
		className: "lift rounded-card border border-line bg-card p-4",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "flex items-start justify-between gap-3",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "min-w-0",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
						to: "/listing/$id",
						params: { id: String(meetup.listingId) },
						className: "display text-xl text-ink",
						children: meetup.listingTitle
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "text-sm text-muted tabular-nums",
						children: formatPrice(meetup.listingPrice)
					})]
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
					className: "shrink-0 rounded-full bg-sand px-2.5 py-1 text-xs font-medium text-ink",
					children: meetupLabel(meetup.status)
				})]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
				className: "mt-3 text-sm text-ink",
				children: [meetup.role === "seller" ? `${other} wants to collect` : `You asked ${other}`, formatWhen(meetup.createdAt) ? ` · ${formatWhen(meetup.createdAt)}` : ""]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "mt-2 text-pretty text-ink",
				children: meetup.message
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
				className: "mt-2 text-sm text-muted",
				children: [meetup.place, meetup.whenNote ? ` · ${meetup.whenNote}` : ""]
			}),
			meetup.status === "open" && meetup.role === "seller" && onAccept && onDecline ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "mt-4 flex flex-wrap gap-2",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
					disabled: busy,
					onClick: onAccept,
					children: "Agree to meet"
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
					variant: "line",
					disabled: busy,
					onClick: onDecline,
					children: "Decline"
				})]
			}) : null,
			(meetup.status === "open" || meetup.status === "accepted") && meetup.role === "buyer" && onCancel ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "mt-4",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
					variant: "line",
					disabled: busy,
					onClick: onCancel,
					children: "Cancel"
				})
			}) : null
		]
	});
}
//#endregion
export { MeetupCard as t };
