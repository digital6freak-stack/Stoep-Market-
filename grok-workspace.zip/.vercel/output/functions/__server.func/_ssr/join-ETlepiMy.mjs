import { w as require_jsx_runtime, x as Navigate } from "../_libs/@tanstack/react-router+[...].mjs";
import { C as useMember, c as SignOutButton, i as Frame, o as Opening, y as saveProfile } from "./ui-BhtY2CpM.mjs";
import { t as ProfileForm } from "./profile-form-CRJMDkjO.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/join-ETlepiMy.js
var import_jsx_runtime = require_jsx_runtime();
function JoinPage() {
	const state = useMember();
	if (state.pending) return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Opening, {});
	if (state.signedOut) return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Navigate, { to: "/login" });
	if (state.failed || !state.me) return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Opening, {
		message: state.failed ?? "Could not open the market",
		onRetry: state.refresh
	});
	if (state.me.profile) return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Navigate, { to: "/" });
	const suggested = state.user?.displayName && !state.user.isDevFallback ? state.user.displayName : "";
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Frame, {
		aside: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(SignOutButton, {}),
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "mx-auto max-w-lg",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
					className: "display-bold text-4xl text-ink",
					children: "Take a place on the stoep"
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "mt-2 text-pretty text-sm text-muted",
					children: "You're registered. Tell neighbours what to call you and which area you can meet in. Then you can post and search."
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "mt-6",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ProfileForm, {
						initial: {
							displayName: suggested,
							area: "",
							bio: ""
						},
						submitLabel: "Step onto the stoep",
						onSubmit: async (draft) => {
							await saveProfile({ data: draft });
							window.location.assign("/");
						}
					})
				})
			]
		})
	});
}
//#endregion
export { JoinPage as component };
