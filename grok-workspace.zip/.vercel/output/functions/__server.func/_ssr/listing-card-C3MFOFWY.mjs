import { b as Link, w as require_jsx_runtime } from "../_libs/@tanstack/react-router+[...].mjs";
import { a as conditionLabel, c as formatPrice, d as statusLabel, i as categoryById } from "./market-BYMNOAra.mjs";
import { a as Shirt, d as BookOpen, f as Bike, i as Smartphone, l as Flower2, m as Armchair, p as Baby, s as Package, u as CookingPot } from "../_libs/lucide-react.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/listing-card-C3MFOFWY.js
var import_jsx_runtime = require_jsx_runtime();
var icons = {
	furniture: Armchair,
	clothes: Shirt,
	kids: Baby,
	kitchen: CookingPot,
	books: BookOpen,
	electronics: Smartphone,
	garden: Flower2,
	sports: Bike,
	other: Package
};
function CategoryPlate({ category, className = "" }) {
	const meta = categoryById(category);
	const Icon = icons[meta.id] ?? Package;
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
		className: `plate plate-${meta.id} grid place-items-center text-ink ${className}`,
		"aria-hidden": true,
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Icon, {
			className: "size-8",
			strokeWidth: 1.5
		})
	});
}
function StatusPill({ status }) {
	if (status === "sold") return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
		className: "rounded-full bg-ink px-2.5 py-1 text-xs font-medium text-paper",
		children: statusLabel(status)
	});
	if (status === "holding") return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
		className: "rounded-full bg-sand px-2.5 py-1 text-xs font-medium text-ink",
		children: statusLabel(status)
	});
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
		className: "rounded-full bg-moss px-2.5 py-1 text-xs font-medium text-moss-ink",
		children: statusLabel(status)
	});
}
function ListingCardView({ listing }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Link, {
		to: "/listing/$id",
		params: { id: String(listing.id) },
		className: "lift block overflow-hidden rounded-card border border-line bg-card",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "relative aspect-[4/3]",
			children: [
				listing.photo ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("img", {
					src: listing.photo,
					alt: "",
					className: "h-full w-full object-cover"
				}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)(CategoryPlate, {
					category: listing.category,
					className: "h-full w-full"
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
					className: "absolute top-3 left-3 rounded-full bg-clay px-3 py-1 text-sm font-medium text-clay-ink tabular-nums",
					children: formatPrice(listing.price)
				}),
				listing.status !== "available" ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
					className: "absolute top-3 right-3",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(StatusPill, { status: listing.status })
				}) : null
			]
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "space-y-1 px-4 py-3",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
					className: "display text-xl leading-tight text-ink",
					children: listing.title
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
					className: "text-sm text-muted",
					children: [
						conditionLabel(listing.condition),
						" · ",
						listing.area
					]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "text-sm text-ink",
					children: listing.mine ? "Your post" : listing.sellerName
				})
			]
		})]
	});
}
//#endregion
export { ListingCardView as n, StatusPill as r, CategoryPlate as t };
