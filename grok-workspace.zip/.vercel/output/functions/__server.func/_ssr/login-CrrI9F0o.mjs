import { o as __toESM } from "../_runtime.mjs";
import { Z as require_react, w as require_jsx_runtime, x as Navigate } from "../_libs/@tanstack/react-router+[...].mjs";
import { r as signIn, t as authClient } from "./client-1vAx-gM_.mjs";
import { t as GROK_PROVIDERS } from "./server-BzIhfVrm.mjs";
import { S as useCurrentUserState, f as fieldClass, i as Frame, n as Button, o as Opening, r as Field, t as Alert, w as useMounted } from "./ui-BhtY2CpM.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/login-CrrI9F0o.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
var BEARER_KEY = "grok-auth.bearer-token";
function LoginPage() {
	const mounted = useMounted();
	const { user, isPending } = useCurrentUserState();
	if (!mounted || isPending) return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Opening, {});
	if (user) return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Navigate, { to: "/" });
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Frame, { children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(LoginForm, {}) });
}
function LoginForm() {
	const [mode, setMode] = (0, import_react.useState)("register");
	const [name, setName] = (0, import_react.useState)("");
	const [email, setEmail] = (0, import_react.useState)("");
	const [password, setPassword] = (0, import_react.useState)("");
	const [error, setError] = (0, import_react.useState)(null);
	const [busy, setBusy] = (0, import_react.useState)(false);
	async function onSubmit(event) {
		event.preventDefault();
		setBusy(true);
		setError(null);
		try {
			const path = mode === "register" ? "/api/auth/sign-up/email" : "/api/auth/sign-in/email";
			const body = mode === "register" ? {
				name: name.trim(),
				email: email.trim(),
				password
			} : {
				email: email.trim(),
				password
			};
			const res = await fetch(path, {
				method: "POST",
				headers: { "content-type": "application/json" },
				credentials: "include",
				body: JSON.stringify(body)
			});
			const token = res.headers.get("set-auth-token");
			const payload = await res.json().catch(() => null);
			if (!res.ok) throw new Error(payload?.message || (mode === "register" ? "Could not register" : "Could not sign in"));
			if (token) sessionStorage.setItem(BEARER_KEY, token);
			if (!(await authClient.getSession()).data?.user) throw new Error("That didn't keep you signed in. Try again, or continue with Google.");
			window.location.assign("/");
		} catch (err) {
			setError(err instanceof Error ? err.message : "Could not continue");
			setBusy(false);
		}
	}
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "mx-auto w-full max-w-md",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "text-sm font-medium text-clay",
				children: "Members only"
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
				className: "display-bold mt-2 text-4xl text-ink",
				children: mode === "register" ? "Register for Stoep" : "Welcome back"
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "mt-2 text-pretty text-sm text-muted",
				children: "Buyers and sellers use the same account. You need one before you can see posts or put something out."
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("form", {
					onSubmit,
					className: "mt-6 space-y-4",
					children: [
						error ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Alert, { children: error }) : null,
						mode === "register" ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
							label: "Your name",
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
								className: fieldClass,
								value: name,
								required: true,
								autoComplete: "name",
								onChange: (event) => setName(event.target.value)
							})
						}) : null,
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
							label: "Email",
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
								className: fieldClass,
								type: "email",
								value: email,
								required: true,
								autoComplete: "email",
								onChange: (event) => setEmail(event.target.value)
							})
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
							label: "Password",
							hint: "At least 8 characters.",
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
								className: fieldClass,
								type: "password",
								value: password,
								required: true,
								minLength: 8,
								autoComplete: mode === "register" ? "new-password" : "current-password",
								onChange: (event) => setPassword(event.target.value)
							})
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
							type: "submit",
							disabled: busy,
							className: "w-full",
							children: busy ? "One moment…" : mode === "register" ? "Create my account" : "Sign in"
						})
					]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
					type: "button",
					className: "mt-4 min-h-11 text-sm font-medium text-ink",
					onClick: () => {
						setMode(mode === "register" ? "sign-in" : "register");
						setError(null);
					},
					children: mode === "register" ? "I already have an account" : "I need to register"
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "my-6 flex items-center gap-3 text-sm text-muted",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { className: "h-px flex-1 bg-line" }),
						"or",
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { className: "h-px flex-1 bg-line" })
					]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "space-y-2",
					children: GROK_PROVIDERS.map((provider) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Button, {
						variant: "line",
						className: "w-full",
						onClick: () => {
							setError(null);
							signIn(provider.providerId, { callbackURL: "/" }).catch((err) => {
								setError(err instanceof Error ? err.message : "Could not continue");
							});
						},
						children: ["Continue with ", provider.label]
					}, provider.providerId))
				})
			] })
		]
	});
}
//#endregion
export { LoginPage as component };
