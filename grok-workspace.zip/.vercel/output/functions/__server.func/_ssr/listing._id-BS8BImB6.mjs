import { o as __toESM } from "../_runtime.mjs";
import { S as useNavigate, Z as require_react, b as Link, w as require_jsx_runtime } from "../_libs/@tanstack/react-router+[...].mjs";
import { a as conditionLabel, c as formatPrice, i as categoryById, l as formatWhen, s as errorText } from "./market-BYMNOAra.mjs";
import { _ as requestMeetup, a as MemberGate, b as setListingStatus, d as deleteListing, f as fieldClass, l as cancelMeetup, n as Button, p as getListing, r as Field, t as Alert, v as respondMeetup, x as updateListing } from "./ui-BhtY2CpM.mjs";
import { n as Route$1 } from "./router-C4incqYv.mjs";
import { r as StatusPill, t as CategoryPlate } from "./listing-card-C3MFOFWY.mjs";
import { t as ListingForm } from "./listing-form-7S23upyS.mjs";
import { t as MeetupCard } from "./meetup-card-aRrQmQe4.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/listing._id-BS8BImB6.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
function ListingRoute() {
	const { id } = Route$1.useParams();
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(MemberGate, { children: () => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ListingScreen, { id: Number(id) }) });
}
function ListingScreen({ id }) {
	const navigate = useNavigate();
	const [page, setPage] = (0, import_react.useState)(void 0);
	const [error, setError] = (0, import_react.useState)(null);
	const [editing, setEditing] = (0, import_react.useState)(false);
	const [busy, setBusy] = (0, import_react.useState)(false);
	const [confirmDelete, setConfirmDelete] = (0, import_react.useState)(false);
	const [tick, setTick] = (0, import_react.useState)(0);
	(0, import_react.useEffect)(() => {
		if (!Number.isInteger(id) || id < 1) {
			setPage(null);
			return;
		}
		let live = true;
		getListing({ data: { id } }).then((next) => {
			if (live) setPage(next);
		}).catch((err) => {
			if (!live) return;
			setError(errorText(err));
			setPage(null);
		});
		return () => {
			live = false;
		};
	}, [id, tick]);
	async function run(task) {
		setBusy(true);
		setError(null);
		try {
			await task();
			setTick((n) => n + 1);
			setEditing(false);
			setConfirmDelete(false);
		} catch (err) {
			setError(errorText(err));
		} finally {
			setBusy(false);
		}
	}
	if (page === void 0) return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
		className: "text-sm text-muted",
		children: "Fetching that post…"
	});
	if (!page) return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "mx-auto max-w-lg text-center",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
				className: "display-bold text-4xl text-ink",
				children: "That post is gone"
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "mt-2 text-sm text-muted",
				children: error ?? "It may have been removed."
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
				to: "/",
				className: "mt-4 inline-flex min-h-11 items-center text-sm font-medium text-clay",
				children: "Back to the board"
			})
		]
	});
	const { listing } = page;
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "mx-auto grid max-w-5xl gap-6 md:grid-cols-[minmax(0,1.1fr)_minmax(0,0.9fr)]",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
			to: "/",
			className: "text-sm font-medium text-muted",
			children: "Back to the board"
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
			className: "lift mt-3 overflow-hidden rounded-card border border-line bg-card",
			children: listing.photo ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("img", {
				src: listing.photo,
				alt: "",
				className: "aspect-[4/3] w-full object-cover"
			}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)(CategoryPlate, {
				category: listing.category,
				className: "aspect-[4/3] w-full"
			})
		})] }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "space-y-4",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "flex flex-wrap items-center gap-2",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(StatusPill, { status: listing.status }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
						className: "text-sm text-muted",
						children: [
							categoryById(listing.category).label,
							" · ",
							conditionLabel(listing.condition)
						]
					})]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
					className: "display-bold text-4xl text-ink",
					children: listing.title
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "display text-3xl text-clay tabular-nums",
					children: formatPrice(listing.price)
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "text-pretty whitespace-pre-wrap text-ink",
					children: listing.description
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
					className: "text-sm text-muted",
					children: [
						"Pickup in ",
						listing.area,
						formatWhen(listing.createdAt) ? ` · posted ${formatWhen(listing.createdAt)}` : ""
					]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "rounded-card border border-line bg-card p-4",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "text-sm text-muted",
							children: listing.mine ? "Your stall" : "Posted by"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "display text-2xl text-ink",
							children: listing.sellerName
						}),
						listing.sellerBio ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "mt-1 text-pretty text-sm text-muted",
							children: listing.sellerBio
						}) : null
					]
				}),
				error ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Alert, { children: error }) : null,
				listing.mine ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(OwnerPanel, {
					page,
					editing,
					busy,
					confirmDelete,
					onEdit: () => setEditing((value) => !value),
					onConfirmDelete: () => setConfirmDelete(true),
					onRun: run,
					onDelete: async () => {
						await deleteListing({ data: { id: listing.id } });
						await navigate({ to: "/" });
					}
				}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)(BuyerPanel, {
					page,
					busy,
					onRun: run
				})
			]
		})]
	});
}
function OwnerPanel({ page, editing, busy, confirmDelete, onEdit, onConfirmDelete, onRun, onDelete }) {
	const { listing, requests } = page;
	const draft = {
		title: listing.title,
		description: listing.description,
		price: String(listing.price),
		category: listing.category,
		condition: listing.condition,
		area: listing.area,
		photo: listing.photo,
		photoAction: "keep"
	};
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "space-y-4",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "flex flex-wrap gap-2",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
						variant: "line",
						disabled: busy,
						onClick: onEdit,
						children: editing ? "Close editor" : "Edit post"
					}),
					listing.status !== "sold" ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
						disabled: busy,
						onClick: () => onRun(() => setListingStatus({ data: {
							id: listing.id,
							status: "sold"
						} })),
						children: "Mark as gone"
					}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
						variant: "moss",
						disabled: busy,
						onClick: () => onRun(() => setListingStatus({ data: {
							id: listing.id,
							status: "available"
						} })),
						children: "Put it back"
					}),
					listing.status === "holding" ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
						variant: "line",
						disabled: busy,
						onClick: () => onRun(() => setListingStatus({ data: {
							id: listing.id,
							status: "available"
						} })),
						children: "Cancel the pickup"
					}) : null,
					confirmDelete ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
						variant: "ink",
						disabled: busy,
						onClick: () => onRun(onDelete),
						children: "Remove for good"
					}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
						variant: "quiet",
						disabled: busy,
						onClick: onConfirmDelete,
						children: "Remove"
					})
				]
			}),
			editing ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ListingForm, {
				initial: draft,
				submitLabel: "Save changes",
				onSubmit: (next) => onRun(() => updateListing({ data: {
					id: listing.id,
					title: next.title,
					description: next.description,
					price: Number(next.price || "0"),
					category: next.category,
					condition: next.condition,
					area: next.area,
					photo: next.photo,
					photoAction: next.photoAction
				} }))
			}) : null,
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
				className: "space-y-3",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
					className: "display text-2xl text-ink",
					children: "People who asked"
				}), requests.length === 0 ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "text-sm text-muted",
					children: "No one has asked yet."
				}) : requests.map((meetup) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(MeetupCard, {
					meetup,
					busy,
					onAccept: () => onRun(() => respondMeetup({ data: {
						id: meetup.id,
						status: "accepted"
					} })),
					onDecline: () => onRun(() => respondMeetup({ data: {
						id: meetup.id,
						status: "declined"
					} }))
				}, meetup.id))]
			})
		]
	});
}
function BuyerPanel({ page, busy, onRun }) {
	const { listing, myMeetup } = page;
	const [message, setMessage] = (0, import_react.useState)("");
	const [place, setPlace] = (0, import_react.useState)("");
	const [whenNote, setWhenNote] = (0, import_react.useState)("");
	const openRequest = myMeetup && (myMeetup.status === "open" || myMeetup.status === "accepted");
	if (listing.status === "sold") return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
		className: "text-sm text-muted",
		children: "This has already gone."
	});
	if (openRequest && myMeetup) return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(MeetupCard, {
		meetup: myMeetup,
		busy,
		onCancel: () => onRun(() => cancelMeetup({ data: { id: myMeetup.id } }))
	});
	function submit(event) {
		event.preventDefault();
		onRun(() => requestMeetup({ data: {
			listingId: listing.id,
			message,
			place,
			whenNote
		} }));
	}
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("form", {
		onSubmit: submit,
		className: "space-y-3 rounded-card border border-line bg-card p-4",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
				className: "display text-2xl text-ink",
				children: "Ask to meet"
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "text-pretty text-sm text-muted",
				children: listing.status === "holding" ? "Someone is already arranging pickup. You can still ask, in case it falls through." : "Suggest a public place and a time. Pay them in cash when you collect it."
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
				label: "Note",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("textarea", {
					className: `${fieldClass} min-h-24 py-3`,
					value: message,
					required: true,
					maxLength: 500,
					onChange: (event) => setMessage(event.target.value)
				})
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
				label: "Where",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
					className: fieldClass,
					value: place,
					required: true,
					maxLength: 120,
					onChange: (event) => setPlace(event.target.value)
				})
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
				label: "When",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
					className: fieldClass,
					value: whenNote,
					required: true,
					maxLength: 120,
					placeholder: "Saturday morning",
					onChange: (event) => setWhenNote(event.target.value)
				})
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
				type: "submit",
				disabled: busy,
				children: busy ? "Sending…" : "Send request"
			})
		]
	});
}
//#endregion
export { ListingRoute as component };
