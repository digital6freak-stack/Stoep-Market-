import { o as __toESM } from "../_runtime.mjs";
import { Z as require_react, w as require_jsx_runtime } from "../_libs/@tanstack/react-router+[...].mjs";
import { s as errorText } from "./market-BYMNOAra.mjs";
import { a as MemberGate, h as listMeetups, l as cancelMeetup, t as Alert, v as respondMeetup } from "./ui-BhtY2CpM.mjs";
import { t as MeetupCard } from "./meetup-card-aRrQmQe4.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/meets-Bd8Fb4HI.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
function MeetsPage() {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(MemberGate, { children: () => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Meets, {}) });
}
function Meets() {
	const [rows, setRows] = (0, import_react.useState)(null);
	const [error, setError] = (0, import_react.useState)(null);
	const [busy, setBusy] = (0, import_react.useState)(null);
	const [tab, setTab] = (0, import_react.useState)("in");
	const [tick, setTick] = (0, import_react.useState)(0);
	(0, import_react.useEffect)(() => {
		let live = true;
		listMeetups().then((next) => {
			if (!live) return;
			setRows(next);
			setError(null);
		}).catch((err) => {
			if (!live) return;
			setError(errorText(err));
		});
		return () => {
			live = false;
		};
	}, [tick]);
	const incoming = (rows ?? []).filter((row) => row.role === "seller");
	const outgoing = (rows ?? []).filter((row) => row.role === "buyer");
	const shown = tab === "in" ? incoming : outgoing;
	async function run(id, task) {
		setBusy(id);
		setError(null);
		try {
			await task();
			setTick((n) => n + 1);
		} catch (err) {
			setError(errorText(err));
		} finally {
			setBusy(null);
		}
	}
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "mx-auto max-w-xl space-y-4",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
				className: "display-bold text-4xl text-ink",
				children: "Meetups"
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "mt-2 text-pretty text-sm text-muted",
				children: "Agree a public place, in daylight. Stoep doesn't take payment or arrange a driver."
			})] }),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "flex gap-2",
				role: "tablist",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(TabButton, {
					active: tab === "in",
					onClick: () => setTab("in"),
					label: `Asked of you (${incoming.length})`
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(TabButton, {
					active: tab === "out",
					onClick: () => setTab("out"),
					label: `You asked (${outgoing.length})`
				})]
			}),
			error ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Alert, { children: error }) : null,
			rows === null ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "text-sm text-muted",
				children: "Looking for meetups…"
			}) : shown.length === 0 ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "rounded-card border border-dashed border-line bg-card px-4 py-8 text-center text-sm text-pretty text-muted",
				children: tab === "in" ? "When someone wants something you've posted, it lands here." : "Open a post and ask to meet. Your note shows up here."
			}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)("ul", {
				className: "space-y-3",
				children: shown.map((meetup) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("li", { children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(MeetupCard, {
					meetup,
					busy: busy === meetup.id,
					onAccept: () => run(meetup.id, () => respondMeetup({ data: {
						id: meetup.id,
						status: "accepted"
					} })),
					onDecline: () => run(meetup.id, () => respondMeetup({ data: {
						id: meetup.id,
						status: "declined"
					} })),
					onCancel: () => run(meetup.id, () => cancelMeetup({ data: { id: meetup.id } }))
				}) }, meetup.id))
			})
		]
	});
}
function TabButton({ active, label, onClick }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
		type: "button",
		role: "tab",
		"aria-selected": active,
		onClick,
		className: `min-h-11 flex-1 rounded-full px-3 text-sm font-medium ${active ? "bg-ink text-paper" : "border border-line bg-card text-ink"}`,
		children: label
	});
}
//#endregion
export { MeetsPage as component };
