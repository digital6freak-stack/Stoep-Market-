import { S as useNavigate, w as require_jsx_runtime } from "../_libs/@tanstack/react-router+[...].mjs";
import { a as MemberGate, u as createListing } from "./ui-BhtY2CpM.mjs";
import { t as ListingForm } from "./listing-form-7S23upyS.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/sell-C4WexyDe.js
var import_jsx_runtime = require_jsx_runtime();
function SellPage() {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(MemberGate, { children: (profile) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(SellForm, { profile }) });
}
function SellForm({ profile }) {
	const navigate = useNavigate();
	const initial = {
		title: "",
		description: "",
		price: "",
		category: "",
		condition: "good",
		area: profile.area,
		photo: null,
		photoAction: "keep"
	};
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "mx-auto max-w-xl",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
				className: "display-bold text-4xl text-ink",
				children: "Put something out"
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "mt-2 text-pretty text-sm text-muted",
				children: "Say what it is, what you'll take for it, and where someone can collect it. You meet them yourself."
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "mt-6",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ListingForm, {
					initial,
					submitLabel: "Put it on the stoep",
					onSubmit: async (draft) => {
						const created = await createListing({ data: {
							title: draft.title,
							description: draft.description,
							price: Number(draft.price || "0"),
							category: draft.category,
							condition: draft.condition,
							area: draft.area,
							photo: draft.photo
						} });
						await navigate({
							to: "/listing/$id",
							params: { id: String(created.id) }
						});
					}
				})
			})
		]
	});
}
//#endregion
export { SellPage as component };
