import { o as __toESM } from "../_runtime.mjs";
import { Z as require_react, w as require_jsx_runtime } from "../_libs/@tanstack/react-router+[...].mjs";
import { n as CONDITIONS, t as CATEGORIES } from "./market-BYMNOAra.mjs";
import { f as fieldClass, n as Button, r as Field, t as Alert } from "./ui-BhtY2CpM.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/listing-form-7S23upyS.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
async function readPhoto(file) {
	if (!file.type.startsWith("image/")) throw new Error("Choose a photo");
	const url = URL.createObjectURL(file);
	try {
		const img = await new Promise((resolve, reject) => {
			const image = new Image();
			image.onload = () => resolve(image);
			image.onerror = () => reject(/* @__PURE__ */ new Error("Could not read that photo. Try a JPEG."));
			image.src = url;
		});
		const scale = Math.min(1, 960 / Math.max(img.width, img.height));
		const canvas = document.createElement("canvas");
		canvas.width = Math.max(1, Math.round(img.width * scale));
		canvas.height = Math.max(1, Math.round(img.height * scale));
		const ctx = canvas.getContext("2d");
		if (!ctx) throw new Error("Could not read that photo");
		ctx.drawImage(img, 0, 0, canvas.width, canvas.height);
		const data = canvas.toDataURL("image/jpeg", .72);
		if (data.length > 22e4) throw new Error("That photo is still too big. Try a smaller one.");
		return data;
	} finally {
		URL.revokeObjectURL(url);
	}
}
function ListingForm({ initial, submitLabel, onSubmit }) {
	const [draft, setDraft] = (0, import_react.useState)(initial);
	const [error, setError] = (0, import_react.useState)(null);
	const [busy, setBusy] = (0, import_react.useState)(false);
	const fileRef = (0, import_react.useRef)(null);
	const preview = draft.photoAction === "clear" ? null : draft.photo;
	async function handleSubmit(event) {
		event.preventDefault();
		setBusy(true);
		setError(null);
		try {
			await onSubmit(draft);
		} catch (err) {
			setError(err instanceof Error ? err.message : "Could not save that");
			setBusy(false);
		}
	}
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("form", {
		onSubmit: handleSubmit,
		className: "space-y-4",
		children: [
			error ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Alert, { children: error }) : null,
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
				label: "What is it?",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
					className: fieldClass,
					value: draft.title,
					maxLength: 80,
					required: true,
					onChange: (event) => setDraft({
						...draft,
						title: event.target.value
					})
				})
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
				label: "The honest description",
				hint: "What's wrong with it, what's included, why you're letting it go.",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("textarea", {
					className: `${fieldClass} min-h-32 py-3`,
					value: draft.description,
					maxLength: 2e3,
					required: true,
					onChange: (event) => setDraft({
						...draft,
						description: event.target.value
					})
				})
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "grid gap-4 sm:grid-cols-2",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
						label: "Price in rands",
						hint: "0 if you're giving it away.",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
							className: `${fieldClass} tabular-nums`,
							inputMode: "numeric",
							value: draft.price,
							required: true,
							onChange: (event) => setDraft({
								...draft,
								price: event.target.value.replace(/[^\d]/g, "")
							})
						})
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
						label: "Pickup area",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
							className: fieldClass,
							value: draft.area,
							maxLength: 60,
							required: true,
							onChange: (event) => setDraft({
								...draft,
								area: event.target.value
							})
						})
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
						label: "Category",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("select", {
							className: fieldClass,
							value: draft.category,
							required: true,
							onChange: (event) => setDraft({
								...draft,
								category: event.target.value
							}),
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
								value: "",
								children: "Choose"
							}), CATEGORIES.map((item) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
								value: item.id,
								children: item.label
							}, item.id))]
						})
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
						label: "Condition",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("select", {
							className: fieldClass,
							value: draft.condition,
							required: true,
							onChange: (event) => setDraft({
								...draft,
								condition: event.target.value
							}),
							children: CONDITIONS.map((item) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
								value: item.id,
								children: item.label
							}, item.id))
						})
					})
				]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "space-y-2",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
						className: "block text-sm font-medium text-ink",
						children: "Photo"
					}),
					preview ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("img", {
						src: preview,
						alt: "",
						className: "aspect-[4/3] w-full max-w-sm rounded-card object-cover"
					}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "text-sm text-muted",
						children: "Optional. A clear photo gets it off the stoep faster."
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "flex flex-wrap gap-2",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
							variant: "line",
							onClick: () => fileRef.current?.click(),
							children: preview ? "Change photo" : "Add a photo"
						}), preview ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
							variant: "quiet",
							onClick: () => setDraft({
								...draft,
								photo: null,
								photoAction: "clear"
							}),
							children: "Remove"
						}) : null]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
						ref: fileRef,
						type: "file",
						accept: "image/*",
						className: "sr-only",
						onChange: (event) => {
							const file = event.target.files?.[0];
							event.target.value = "";
							if (!file) return;
							readPhoto(file).then((photo) => setDraft((current) => ({
								...current,
								photo,
								photoAction: "set"
							}))).catch((err) => setError(err instanceof Error ? err.message : "Could not read that photo"));
						}
					})
				]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
				type: "submit",
				disabled: busy,
				className: "w-full sm:w-auto",
				children: busy ? "Saving…" : submitLabel
			})
		]
	});
}
//#endregion
export { ListingForm as t };
