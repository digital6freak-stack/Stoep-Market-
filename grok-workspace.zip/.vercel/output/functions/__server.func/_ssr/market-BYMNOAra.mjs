import { n as createMiddleware } from "./ssr.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/market-BYMNOAra.js
/**
* Auth middleware for server functions — the standard way to get the caller's
* verified user id. When deployed the session cookie is same-origin and rides
* along automatically. In the live preview the client also forwards the bearer
* token (partitioned cookies) via the `.client` hook below — call sites do not
* thread it themselves.
*
*   import { createServerFn } from "@tanstack/react-start";
*   import { getSql } from "@/lib/db";
*   import { authMiddleware } from "@/lib/auth/middleware";
*
*   export const listTodos = createServerFn({ method: "GET" })
*     .middleware([authMiddleware])
*     .handler(async ({ context }) => {
*       const sql = await getSql();
*       return sql`select * from todos where user_id = ${context.userId}`;
*     });
*
* Signed out with auth on (live preview included) -> throws `UnauthorizedError`
* (see `verify.server.ts`). With auth disabled (`VITE_AUTH_ENABLED=false`, the
* shipped default) it resolves the shared dev user — but throws instead when a
* `DATABASE_URL` is also set, so an app without sign-in must not use this at
* all. On the auth-on path, use it on every server function that touches
* per-user data and scope every query by `context.userId`.
*/
var authMiddleware = createMiddleware({ type: "function" }).client(async ({ next }) => {
	const { getBearerToken } = await import("./client-1vAx-gM_.mjs").then((n) => n.n).then((n) => n.n);
	return next({ sendContext: { bearerToken: getBearerToken() ?? void 0 } });
}).server(async ({ next, context }) => {
	const { assertSameSiteRequest } = await import("./isolation.server-CGNg1r0B.mjs");
	const { requireUserId } = await import("./verify.server-aeh-G9dh.mjs");
	assertSameSiteRequest();
	return next({ context: { userId: await requireUserId(context.bearerToken) } });
});
var CATEGORIES = [
	{
		id: "furniture",
		label: "Furniture"
	},
	{
		id: "clothes",
		label: "Clothes"
	},
	{
		id: "kids",
		label: "Kids"
	},
	{
		id: "kitchen",
		label: "Kitchen"
	},
	{
		id: "books",
		label: "Books"
	},
	{
		id: "electronics",
		label: "Electronics"
	},
	{
		id: "garden",
		label: "Garden"
	},
	{
		id: "sports",
		label: "Sports"
	},
	{
		id: "other",
		label: "Other"
	}
];
var CONDITIONS = [
	{
		id: "like-new",
		label: "Like new"
	},
	{
		id: "good",
		label: "Good"
	},
	{
		id: "fair",
		label: "Fair"
	},
	{
		id: "for-parts",
		label: "For parts"
	}
];
var emptyBoard = {
	q: "",
	category: "",
	condition: "",
	area: "",
	maxPrice: -1,
	includeSold: false
};
function categoryById(id) {
	return CATEGORIES.find((item) => item.id === id) ?? CATEGORIES[CATEGORIES.length - 1];
}
function conditionLabel(id) {
	return CONDITIONS.find((item) => item.id === id)?.label ?? id;
}
function statusLabel(status) {
	if (status === "sold") return "Gone";
	if (status === "holding") return "Pickup arranged";
	return "On the stoep";
}
function meetupLabel(status) {
	if (status === "accepted") return "Agreed";
	if (status === "declined") return "Declined";
	if (status === "cancelled") return "Cancelled";
	return "Waiting";
}
function formatPrice(price) {
	if (price <= 0) return "Free";
	return `R\u00a0${new Intl.NumberFormat("en-ZA").format(price)}`;
}
function formatWhen(value) {
	const date = new Date(value);
	if (Number.isNaN(date.getTime())) return "";
	return new Intl.DateTimeFormat("en-ZA", {
		day: "numeric",
		month: "short",
		year: "numeric"
	}).format(date);
}
function errorText(err) {
	if (err instanceof Error && err.message) return err.message;
	if (typeof err === "object" && err && "message" in err && typeof err.message === "string") return err.message;
	return "Something went wrong. Try again.";
}
//#endregion
export { conditionLabel as a, formatPrice as c, statusLabel as d, categoryById as i, formatWhen as l, CONDITIONS as n, emptyBoard as o, authMiddleware as r, errorText as s, CATEGORIES as t, meetupLabel as u };
