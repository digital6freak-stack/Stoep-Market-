import { o as __toESM } from "../_runtime.mjs";
import { Z as require_react, b as Link, p as useRouterState, w as require_jsx_runtime, x as Navigate } from "../_libs/@tanstack/react-router+[...].mjs";
import { a as getServerFnById, i as TSS_SERVER_FUNCTION, r as createServerFn } from "./ssr.mjs";
import { i as signOut, t as authClient } from "./client-1vAx-gM_.mjs";
import { a as hasGateSessionMarker } from "./server-BzIhfVrm.mjs";
import { n as CONDITIONS, r as authMiddleware, s as errorText, t as CATEGORIES } from "./market-BYMNOAra.mjs";
import { c as Handshake, o as Plus, r as Store, t as UserRound } from "../_libs/lucide-react.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/ui-BhtY2CpM.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
/**
* Current user + loading state. Same behavior in live preview and when deployed:
*   - Auth enabled -> the real signed-in user; `user` is `null` while
*                            the session resolves (`isPending: true`) and when
*                            signed out (`isPending: false`). Session comes from
*                            Better Auth `useSession()` → `/api/auth/get-session`
*                            (cookie when deployed; bearer in live preview).
*   - Auth disabled (`VITE_AUTH_ENABLED=false`) -> `DEV_USER`, never pending.
*
* Protect a route by waiting out `isPending` before acting on `user` —
* redirecting on `user: null` alone bounces signed-in visitors to sign-in on
* every hard reload:
*
*   import { RedirectToSignIn } from "@/lib/auth/gates";
*   const { user, isPending } = useCurrentUserState();
*   if (isPending) return null;              // still resolving — don't redirect yet
*   if (!user) return <RedirectToSignIn />;  // definitely signed out
*
* `authEnabled` is a module-level constant fixed at load, so the guarded hook
* call keeps a stable hook order across every render of a given component.
*/
function useCurrentUserState() {
	return useSessionUserState();
}
function useSessionUserState() {
	const { data, isPending } = authClient.useSession();
	const id = data?.user.id;
	const displayName = data?.user.name ?? null;
	const primaryEmail = data?.user.email ?? null;
	const profileImageUrl = data?.user.image ?? null;
	const user = (0, import_react.useMemo)(() => id ? {
		id,
		displayName,
		primaryEmail,
		profileImageUrl,
		isDevFallback: false
	} : null, [
		id,
		displayName,
		primaryEmail,
		profileImageUrl
	]);
	return (0, import_react.useMemo)(() => ({
		user,
		isPending
	}), [user, isPending]);
}
/**
* Auth state components — plain wrappers around `useCurrentUserState()`.
*
* With auth on, visitors are signed out until they authenticate — in the sandbox
* live preview too, which does real sign-in. The shared dev user appears only
* when auth is disabled (`VITE_AUTH_ENABLED=false`, the shipped default).
* While the session is still resolving, gates that care about signed-out state
* render nothing so there's no signed-out flash on hard reload.
*/
/** Where `RedirectToSignIn` sends signed-out visitors. Create this route. */
var SIGN_IN_PATH = "/login";
/**
* Client-side redirect to the sign-in route (TanStack `<Navigate>` — NOT a full
* `window.location` reload). A hard navigation re-bootstraps the SPA and re-runs
* session loading, which feels like a second "Loading…" on /login.
*
* Guard routes by waiting out `isPending` first (see `use-current-user`), then
* render this.
*/
function RedirectToSignIn({ to = SIGN_IN_PATH }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Navigate, { to });
}
var createSsrRpc = (functionId) => {
	const url = "/_serverFn/" + functionId;
	const serverFnMeta = { id: functionId };
	const fn = async (...args) => {
		return (await getServerFnById(functionId, { origin: "server" }))(...args);
	};
	return Object.assign(fn, {
		url,
		serverFnMeta,
		[TSS_SERVER_FUNCTION]: true
	});
};
var CATEGORY_IDS = new Set(CATEGORIES.map((item) => item.id));
var CONDITION_IDS = new Set(CONDITIONS.map((item) => item.id));
function asObject(data) {
	if (typeof data !== "object" || data === null || Array.isArray(data)) throw new Error("Invalid request");
	return data;
}
function reqText(value, label, min, max) {
	if (typeof value !== "string") throw new Error(`${label} is required`);
	const trimmed = value.trim();
	if (trimmed.length < min) throw new Error(`${label} needs at least ${min} characters`);
	if (trimmed.length > max) throw new Error(`${label} is too long`);
	return trimmed;
}
function optText(value, max) {
	if (typeof value !== "string") return "";
	const trimmed = value.trim();
	if (trimmed.length > max) throw new Error("That text is too long");
	return trimmed;
}
function priceOf(value) {
	const number = typeof value === "number" ? value : Number(value);
	if (!Number.isInteger(number) || number < 0 || number > 1e6) throw new Error("Use a whole number of rands, from 0 (free) up to 1 000 000");
	return number;
}
function idOf(value) {
	const number = typeof value === "number" ? value : Number(value);
	if (!Number.isInteger(number) || number < 1) throw new Error("That post could not be found");
	return number;
}
function photoOrNull(value) {
	if (value == null || value === "") return null;
	if (typeof value !== "string" || !value.startsWith("data:image/jpeg;base64,")) throw new Error("Use a JPEG photo");
	if (value.length > 22e4) throw new Error("That photo is too large");
	return value;
}
function boardQuery(data) {
	const body = asObject(data ?? {});
	const category = optText(body.category, 40);
	if (category && !CATEGORY_IDS.has(category)) throw new Error("Unknown category");
	const condition = optText(body.condition, 40);
	if (condition && !CONDITION_IDS.has(condition)) throw new Error("Unknown condition");
	let maxPrice = -1;
	if (body.maxPrice !== void 0 && body.maxPrice !== null && body.maxPrice !== -1 && body.maxPrice !== "") maxPrice = priceOf(body.maxPrice);
	return {
		q: optText(body.q, 80),
		category,
		condition,
		area: optText(body.area, 60),
		maxPrice,
		includeSold: body.includeSold === true
	};
}
var getMe = createServerFn({ method: "GET" }).middleware([authMiddleware]).handler(createSsrRpc("e9d8cfea6297f7170a5aaeccfe282a2ab1e7a074f2d807f2f36b6702f1334f60"));
var saveProfile = createServerFn({ method: "POST" }).validator((data) => {
	const body = asObject(data);
	return {
		displayName: reqText(body.displayName, "Your name", 2, 40),
		area: reqText(body.area, "Your area", 2, 60),
		bio: optText(body.bio, 280)
	};
}).middleware([authMiddleware]).handler(createSsrRpc("5ddef10115707990e8f6530ef56d0cf719461bfc45665186ad929a0556b85479"));
var listListings = createServerFn({ method: "GET" }).validator((data) => boardQuery(data)).middleware([authMiddleware]).handler(createSsrRpc("b0cb5b2ebbc42bfc06b9c15036afc025dc4c30f4738b1c26f3c71ad1680dfec5"));
var getListing = createServerFn({ method: "GET" }).validator((data) => {
	return { id: idOf(asObject(data).id) };
}).middleware([authMiddleware]).handler(createSsrRpc("12462749851a29d1a06557bb0942ec7b27862338b1a32be158f26e172482b0c4"));
function listingInput(data, withPhotoAction) {
	const body = asObject(data);
	const category = reqText(body.category, "Category", 1, 40);
	if (!CATEGORY_IDS.has(category)) throw new Error("Choose a category");
	const condition = reqText(body.condition, "Condition", 1, 40);
	if (!CONDITION_IDS.has(condition)) throw new Error("Choose a condition");
	const photoAction = body.photoAction === "set" || body.photoAction === "clear" ? body.photoAction : "keep";
	const photo = photoAction === "set" || !withPhotoAction ? photoOrNull(body.photo) : null;
	if ((photoAction === "set" || !withPhotoAction) && body.photo) photoOrNull(body.photo);
	return {
		title: reqText(body.title, "Title", 3, 80),
		description: reqText(body.description, "Description", 10, 2e3),
		price: priceOf(body.price),
		category,
		condition,
		area: reqText(body.area, "Pickup area", 2, 60),
		photo: withPhotoAction ? photo : photoOrNull(body.photo),
		photoAction
	};
}
var createListing = createServerFn({ method: "POST" }).validator((data) => listingInput(data, false)).middleware([authMiddleware]).handler(createSsrRpc("1b019c0c4b1988e0ed8ce7d03c10671e3f9a421b6b2d88e2d40cc192883baa61"));
var updateListing = createServerFn({ method: "POST" }).validator((data) => {
	return {
		id: idOf(asObject(data).id),
		...listingInput(data, true)
	};
}).middleware([authMiddleware]).handler(createSsrRpc("3999ef162b72775a957788ca60ad22f8a3d5d96416844602ce3029045f8aae06"));
var setListingStatus = createServerFn({ method: "POST" }).validator((data) => {
	const body = asObject(data);
	const status = body.status === "sold" ? "sold" : body.status === "available" ? "available" : "";
	if (!status) throw new Error("Choose available or sold");
	return {
		id: idOf(body.id),
		status
	};
}).middleware([authMiddleware]).handler(createSsrRpc("b3b9725a65a3b00c3f8458b22a884040ae6b3670d700e3d780512ac98cce5d5c"));
var deleteListing = createServerFn({ method: "POST" }).validator((data) => {
	return { id: idOf(asObject(data).id) };
}).middleware([authMiddleware]).handler(createSsrRpc("b990a953ff7d82c2d3e09828ee652cc9e8352dab69831888ed1f9546bf84495b"));
var requestMeetup = createServerFn({ method: "POST" }).validator((data) => {
	const body = asObject(data);
	return {
		listingId: idOf(body.listingId),
		message: reqText(body.message, "A note", 2, 500),
		place: reqText(body.place, "A meeting place", 2, 120),
		whenNote: reqText(body.whenNote, "A time", 2, 120)
	};
}).middleware([authMiddleware]).handler(createSsrRpc("4c2ef10e11a009927575d324d9d326a4a9a2fdfb590ccc9d471a1490753c123c"));
var respondMeetup = createServerFn({ method: "POST" }).validator((data) => {
	const body = asObject(data);
	const status = body.status === "accepted" || body.status === "declined" ? body.status : "";
	if (!status) throw new Error("Accept or decline");
	return {
		id: idOf(body.id),
		status
	};
}).middleware([authMiddleware]).handler(createSsrRpc("3bb2b77cac1668df11a4094e5630f59bf5898c4fe93bb52afb89130d92b5040a"));
var cancelMeetup = createServerFn({ method: "POST" }).validator((data) => {
	return { id: idOf(asObject(data).id) };
}).middleware([authMiddleware]).handler(createSsrRpc("6056c9849e9bf1742f59a7d687232a82a2e4cedc86dd877e9eb9265b64ded7d5"));
var listMeetups = createServerFn({ method: "GET" }).middleware([authMiddleware]).handler(createSsrRpc("af81fcdd9251e4d088dc9ada0409658fbe4948c38eb9255aa1c15098061d0089"));
var listMine = createServerFn({ method: "GET" }).middleware([authMiddleware]).handler(createSsrRpc("f7b287f85e872ae0b448d8b8273c0734711391b9bcf87f18eedb233b9dbf6b57"));
function subscribe() {
	return () => {};
}
function useMounted() {
	return (0, import_react.useSyncExternalStore)(subscribe, () => true, () => false);
}
function useMember() {
	const mounted = useMounted();
	const { user, isPending } = useCurrentUserState();
	const [me, setMe] = (0, import_react.useState)(null);
	const [failed, setFailed] = (0, import_react.useState)(null);
	const [tick, setTick] = (0, import_react.useState)(0);
	const refresh = (0, import_react.useCallback)(() => setTick((n) => n + 1), []);
	(0, import_react.useEffect)(() => {
		if (!mounted || isPending || !user) return;
		let live = true;
		getMe().then((row) => {
			if (!live) return;
			setMe(row);
			setFailed(null);
		}).catch((err) => {
			if (!live) return;
			setFailed(errorText(err));
		});
		return () => {
			live = false;
		};
	}, [
		mounted,
		isPending,
		user?.id,
		tick
	]);
	return {
		user,
		me,
		failed,
		refresh,
		pending: !mounted || isPending || Boolean(user) && me === null && !failed,
		signedOut: mounted && !isPending && !user
	};
}
function Opening({ message, onRetry }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("main", {
		className: "grid min-h-screen place-items-center px-6",
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "text-center",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "display-bold text-4xl text-ink",
					children: "Stoep"
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "mt-3 text-sm text-muted",
					children: message ?? "Opening the market…"
				}),
				onRetry ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
					type: "button",
					onClick: onRetry,
					className: "mt-4 text-sm font-medium text-clay",
					children: "Try again"
				}) : null
			]
		})
	});
}
function SignOutButton() {
	const gate = (0, import_react.useSyncExternalStore)(subscribe, hasGateSessionMarker, () => false);
	const [busy, setBusy] = (0, import_react.useState)(false);
	const [failed, setFailed] = (0, import_react.useState)(false);
	if (gate) return null;
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
		type: "button",
		disabled: busy,
		onClick: () => {
			setBusy(true);
			setFailed(false);
			signOut().catch(() => {
				setBusy(false);
				setFailed(true);
			});
		},
		className: "min-h-11 px-2 text-sm font-medium text-muted",
		children: busy ? "Signing out…" : failed ? "Sign out failed — retry" : "Sign out"
	});
}
function Frame({ children, aside }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "min-h-screen",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("header", {
			className: "sticky top-0 z-20 border-b border-line bg-paper/90 backdrop-blur-md",
			children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "mx-auto flex h-16 max-w-5xl items-center justify-between gap-3 px-4",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
					to: "/",
					className: "display-bold text-2xl leading-none text-ink",
					children: "Stoep"
				}), aside]
			})
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
			className: "mx-auto w-full max-w-5xl px-4 py-8",
			children
		})]
	});
}
var links = [
	{
		to: "/",
		label: "Board",
		icon: Store,
		exact: true
	},
	{
		to: "/sell",
		label: "Post",
		icon: Plus,
		exact: false
	},
	{
		to: "/meets",
		label: "Meets",
		icon: Handshake,
		exact: false
	},
	{
		to: "/me",
		label: "Stall",
		icon: UserRound,
		exact: false
	}
];
function Shell({ me, children }) {
	const path = useRouterState({ select: (state) => state.location.pathname });
	const profile = me.profile;
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "min-h-screen",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("header", {
				className: "sticky top-0 z-20 border-b border-line bg-paper/90 backdrop-blur-md",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "mx-auto flex h-16 max-w-5xl items-center justify-between gap-4 px-4",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
							to: "/",
							className: "display-bold shrink-0 text-2xl leading-none text-ink",
							children: "Stoep"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("nav", {
							className: "hidden items-center gap-1 md:flex",
							"aria-label": "Market",
							children: links.map((item) => {
								const active = item.exact ? path === item.to : path.startsWith(item.to);
								return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Link, {
									to: item.to,
									className: `inline-flex min-h-11 items-center rounded-full px-4 text-sm font-medium ${active ? "bg-sand text-ink" : "text-muted"}`,
									children: [item.label, item.to === "/meets" && me.openMeets > 0 ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
										className: "ml-2 inline-flex min-w-5 items-center justify-center rounded-full bg-clay px-1.5 text-xs text-clay-ink tabular-nums",
										children: me.openMeets
									}) : null]
								}, item.to);
							})
						}),
						profile ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
							to: "/me",
							className: "grid size-11 shrink-0 place-items-center rounded-full bg-clay text-sm font-semibold text-clay-ink",
							"aria-label": `${profile.displayName}, your stall`,
							children: profile.displayName.charAt(0).toUpperCase()
						}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)(SignOutButton, {})
					]
				})
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("main", {
				className: "mx-auto w-full max-w-5xl px-4 pt-5 pb-28 md:pb-12",
				children
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("nav", {
				className: "dock fixed inset-x-0 bottom-0 z-20 border-t border-line bg-paper/95 backdrop-blur-md md:hidden",
				"aria-label": "Market",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("ul", {
					className: "mx-auto grid max-w-lg grid-cols-4",
					children: links.map((item) => {
						const active = item.exact ? path === item.to : path.startsWith(item.to);
						const Icon = item.icon;
						return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("li", { children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Link, {
							to: item.to,
							className: `flex min-h-16 flex-col items-center justify-center gap-1 text-xs font-medium ${active ? "text-clay" : "text-muted"}`,
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
								className: "relative",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Icon, {
									className: "size-5",
									strokeWidth: 1.75,
									"aria-hidden": true
								}), item.to === "/meets" && me.openMeets > 0 ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { className: "absolute -top-1 -right-2 size-2 rounded-full bg-clay" }) : null]
							}), item.label]
						}) }, item.to);
					})
				})
			})
		]
	});
}
function MemberGate({ children }) {
	const state = useMember();
	if (state.pending) return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Opening, {});
	if (state.signedOut || state.failed === "Unauthorized") return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(RedirectToSignIn, {});
	if (state.failed || !state.me) return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Opening, {
		message: state.failed ?? "Could not open the market",
		onRetry: state.refresh
	});
	if (!state.me.profile) return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Navigate, { to: "/join" });
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Shell, {
		me: state.me,
		children: children(state.me.profile, state.refresh)
	});
}
var tap = "transition-transform duration-150 ease-out active:not-disabled:scale-[0.96] disabled:opacity-50";
var variants = {
	clay: "bg-clay text-clay-ink",
	moss: "bg-moss text-moss-ink",
	line: "border border-line bg-card text-ink",
	quiet: "bg-transparent text-ink",
	ink: "bg-ink text-paper"
};
function Button({ variant = "clay", className = "", type = "button", ...props }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
		type,
		className: `inline-flex min-h-11 items-center justify-center gap-2 rounded-full px-5 text-sm font-medium ${tap} ${variants[variant]} ${className}`,
		...props
	});
}
var fieldClass = "w-full min-h-11 rounded-2xl border border-line bg-card px-4 text-base text-ink outline-none placeholder:text-muted focus:border-clay";
function Field({ label, hint, children }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
		className: "block",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
				className: "mb-1.5 block text-sm font-medium text-ink",
				children: label
			}),
			children,
			hint ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
				className: "mt-1.5 block text-sm text-pretty text-muted",
				children: hint
			}) : null
		]
	});
}
function Alert({ children }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
		className: "rounded-2xl bg-sand px-4 py-3 text-sm text-pretty text-ink",
		role: "alert",
		children
	});
}
//#endregion
export { useMember as C, useCurrentUserState as S, requestMeetup as _, MemberGate as a, setListingStatus as b, SignOutButton as c, deleteListing as d, fieldClass as f, listMine as g, listMeetups as h, Frame as i, cancelMeetup as l, listListings as m, Button as n, Opening as o, getListing as p, Field as r, Shell as s, Alert as t, createListing as u, respondMeetup as v, useMounted as w, updateListing as x, saveProfile as y };
