import { i as TSS_SERVER_FUNCTION, r as createServerFn } from "./ssr.mjs";
import { r as getSql } from "./db-Clz6ZJpu.mjs";
import { n as CONDITIONS, r as authMiddleware, t as CATEGORIES } from "./market-BYMNOAra.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/market.functions-N46HqtZu.js
var createServerRpc = (serverFnMeta, splitImportFn) => {
	const url = "/_serverFn/" + serverFnMeta.id;
	return Object.assign(splitImportFn, {
		url,
		serverFnMeta,
		[TSS_SERVER_FUNCTION]: true
	});
};
var CATEGORY_IDS = new Set(CATEGORIES.map((item) => item.id));
var CONDITION_IDS = new Set(CONDITIONS.map((item) => item.id));
function asObject(data) {
	if (typeof data !== "object" || data === null || Array.isArray(data)) throw new Error("Invalid request");
	return data;
}
function reqText(value, label, min, max) {
	if (typeof value !== "string") throw new Error(`${label} is required`);
	const trimmed = value.trim();
	if (trimmed.length < min) throw new Error(`${label} needs at least ${min} characters`);
	if (trimmed.length > max) throw new Error(`${label} is too long`);
	return trimmed;
}
function optText(value, max) {
	if (typeof value !== "string") return "";
	const trimmed = value.trim();
	if (trimmed.length > max) throw new Error("That text is too long");
	return trimmed;
}
function priceOf(value) {
	const number = typeof value === "number" ? value : Number(value);
	if (!Number.isInteger(number) || number < 0 || number > 1e6) throw new Error("Use a whole number of rands, from 0 (free) up to 1 000 000");
	return number;
}
function idOf(value) {
	const number = typeof value === "number" ? value : Number(value);
	if (!Number.isInteger(number) || number < 1) throw new Error("That post could not be found");
	return number;
}
function photoOrNull(value) {
	if (value == null || value === "") return null;
	if (typeof value !== "string" || !value.startsWith("data:image/jpeg;base64,")) throw new Error("Use a JPEG photo");
	if (value.length > 22e4) throw new Error("That photo is too large");
	return value;
}
function likePattern(value) {
	return `%${value.replace(/[\\%_]/g, (char) => `\\${char}`)}%`;
}
function boardQuery(data) {
	const body = asObject(data ?? {});
	const category = optText(body.category, 40);
	if (category && !CATEGORY_IDS.has(category)) throw new Error("Unknown category");
	const condition = optText(body.condition, 40);
	if (condition && !CONDITION_IDS.has(condition)) throw new Error("Unknown condition");
	let maxPrice = -1;
	if (body.maxPrice !== void 0 && body.maxPrice !== null && body.maxPrice !== -1 && body.maxPrice !== "") maxPrice = priceOf(body.maxPrice);
	return {
		q: optText(body.q, 80),
		category,
		condition,
		area: optText(body.area, 60),
		maxPrice,
		includeSold: body.includeSold === true
	};
}
function asBool(value) {
	return value === true || value === 1 || value === "t" || value === "true";
}
function toCard(row) {
	return {
		id: Number(row.id),
		title: row.title,
		price: Number(row.price),
		category: row.category,
		condition: row.condition,
		area: row.area,
		status: row.status,
		photo: row.photo,
		createdAt: row.createdAt,
		sellerName: row.sellerName,
		mine: asBool(row.mine)
	};
}
function toMeetup(row) {
	return {
		id: Number(row.id),
		listingId: Number(row.listingId),
		listingTitle: row.listingTitle,
		listingStatus: row.listingStatus,
		listingPrice: Number(row.listingPrice),
		buyerName: row.buyerName,
		sellerName: row.sellerName,
		message: row.message,
		place: row.place,
		whenNote: row.whenNote,
		status: row.status,
		createdAt: row.createdAt,
		role: row.role === "seller" ? "seller" : "buyer"
	};
}
async function db() {
	return getSql();
}
var getMe_createServerFn_handler = createServerRpc({
	id: "e9d8cfea6297f7170a5aaeccfe282a2ab1e7a074f2d807f2f36b6702f1334f60",
	name: "getMe",
	filename: "src/lib/market.functions.ts"
}, (opts) => getMe.__executeServer(opts));
var getMe = createServerFn({ method: "GET" }).middleware([authMiddleware]).handler(getMe_createServerFn_handler, async ({ context }) => {
	const sql = await db();
	const profiles = await sql`
      select display_name as "displayName", area, bio,
        to_char(created_at at time zone 'UTC', 'YYYY-MM-DD"T"HH24:MI:SS"Z"') as "createdAt"
      from profiles
      where user_id = ${context.userId}
      limit 1
    `;
	const counts = await sql`
      select count(*)::int as n from meetups
      where seller_id = ${context.userId} and status = 'open'
    `;
	const row = profiles[0];
	return {
		profile: row ? {
			displayName: row.displayName,
			area: row.area,
			bio: row.bio,
			createdAt: row.createdAt
		} : null,
		openMeets: Number(counts[0]?.n ?? 0)
	};
});
var saveProfile_createServerFn_handler = createServerRpc({
	id: "5ddef10115707990e8f6530ef56d0cf719461bfc45665186ad929a0556b85479",
	name: "saveProfile",
	filename: "src/lib/market.functions.ts"
}, (opts) => saveProfile.__executeServer(opts));
var saveProfile = createServerFn({ method: "POST" }).validator((data) => {
	const body = asObject(data);
	return {
		displayName: reqText(body.displayName, "Your name", 2, 40),
		area: reqText(body.area, "Your area", 2, 60),
		bio: optText(body.bio, 280)
	};
}).middleware([authMiddleware]).handler(saveProfile_createServerFn_handler, async ({ context, data }) => {
	const row = (await (await db())`
      insert into profiles (user_id, display_name, area, bio)
      values (${context.userId}, ${data.displayName}, ${data.area}, ${data.bio})
      on conflict (user_id) do update
        set display_name = excluded.display_name,
            area = excluded.area,
            bio = excluded.bio
      returning display_name as "displayName", area, bio,
        to_char(created_at at time zone 'UTC', 'YYYY-MM-DD"T"HH24:MI:SS"Z"') as "createdAt"
    `)[0];
	if (!row) throw new Error("Could not save your details");
	return row;
});
async function requireMember(userId) {
	const sql = await db();
	if (!(await sql`
    select user_id from profiles where user_id = ${userId} limit 1
  `)[0]) throw new Error("Join the market with your name and area first");
	return sql;
}
var listListings_createServerFn_handler = createServerRpc({
	id: "b0cb5b2ebbc42bfc06b9c15036afc025dc4c30f4738b1c26f3c71ad1680dfec5",
	name: "listListings",
	filename: "src/lib/market.functions.ts"
}, (opts) => listListings.__executeServer(opts));
var listListings = createServerFn({ method: "GET" }).validator((data) => boardQuery(data)).middleware([authMiddleware]).handler(listListings_createServerFn_handler, async ({ context, data }) => {
	const sql = await requireMember(context.userId);
	const qLike = likePattern(data.q);
	const areaLike = likePattern(data.area);
	const sold = data.includeSold ? "yes" : "no";
	return (await sql`
      select
        l.id, l.title, l.price, l.category, l.condition, l.area, l.status, l.photo,
        to_char(l.created_at at time zone 'UTC', 'YYYY-MM-DD"T"HH24:MI:SS"Z"') as "createdAt",
        p.display_name as "sellerName",
        (l.seller_id = ${context.userId}) as mine
      from listings l
      join profiles p on p.user_id = l.seller_id
      where (${sold} = 'yes' or l.status <> 'sold')
        and (${data.category} = '' or l.category = ${data.category})
        and (${data.condition} = '' or l.condition = ${data.condition})
        and (${data.area} = '' or l.area ilike ${areaLike} escape '\\')
        and (${data.maxPrice} < 0 or l.price <= ${data.maxPrice})
        and (
          ${data.q} = ''
          or l.title ilike ${qLike} escape '\\'
          or l.description ilike ${qLike} escape '\\'
          or p.display_name ilike ${qLike} escape '\\'
        )
      order by l.created_at desc
      limit 24
    `).map(toCard);
});
var getListing_createServerFn_handler = createServerRpc({
	id: "12462749851a29d1a06557bb0942ec7b27862338b1a32be158f26e172482b0c4",
	name: "getListing",
	filename: "src/lib/market.functions.ts"
}, (opts) => getListing.__executeServer(opts));
var getListing = createServerFn({ method: "GET" }).validator((data) => {
	return { id: idOf(asObject(data).id) };
}).middleware([authMiddleware]).handler(getListing_createServerFn_handler, async ({ context, data }) => {
	const sql = await requireMember(context.userId);
	const row = (await sql`
      select
        l.id, l.title, l.description, l.price, l.category, l.condition, l.area, l.status, l.photo,
        to_char(l.created_at at time zone 'UTC', 'YYYY-MM-DD"T"HH24:MI:SS"Z"') as "createdAt",
        p.display_name as "sellerName",
        p.bio as "sellerBio",
        (l.seller_id = ${context.userId}) as mine
      from listings l
      join profiles p on p.user_id = l.seller_id
      where l.id = ${data.id}
      limit 1
    `)[0];
	if (!row) return null;
	const listing = {
		...toCard(row),
		description: row.description,
		sellerBio: row.sellerBio
	};
	if (listing.mine) return {
		listing,
		requests: (await sql`
        select
          m.id,
          m.listing_id as "listingId",
          l.title as "listingTitle",
          l.status as "listingStatus",
          l.price as "listingPrice",
          bp.display_name as "buyerName",
          sp.display_name as "sellerName",
          m.message, m.place, m.when_note as "whenNote", m.status,
          to_char(m.created_at at time zone 'UTC', 'YYYY-MM-DD"T"HH24:MI:SS"Z"') as "createdAt",
          'seller' as role
        from meetups m
        join listings l on l.id = m.listing_id
        join profiles bp on bp.user_id = m.buyer_id
        join profiles sp on sp.user_id = m.seller_id
        where m.listing_id = ${data.id} and m.seller_id = ${context.userId}
        order by m.created_at desc
      `).map(toMeetup),
		myMeetup: null
	};
	const mine = await sql`
      select
        m.id,
        m.listing_id as "listingId",
        l.title as "listingTitle",
        l.status as "listingStatus",
        l.price as "listingPrice",
        bp.display_name as "buyerName",
        sp.display_name as "sellerName",
        m.message, m.place, m.when_note as "whenNote", m.status,
        to_char(m.created_at at time zone 'UTC', 'YYYY-MM-DD"T"HH24:MI:SS"Z"') as "createdAt",
        'buyer' as role
      from meetups m
      join listings l on l.id = m.listing_id
      join profiles bp on bp.user_id = m.buyer_id
      join profiles sp on sp.user_id = m.seller_id
      where m.listing_id = ${data.id} and m.buyer_id = ${context.userId}
      order by m.created_at desc
      limit 1
    `;
	return {
		listing,
		requests: [],
		myMeetup: mine[0] ? toMeetup(mine[0]) : null
	};
});
function listingInput(data, withPhotoAction) {
	const body = asObject(data);
	const category = reqText(body.category, "Category", 1, 40);
	if (!CATEGORY_IDS.has(category)) throw new Error("Choose a category");
	const condition = reqText(body.condition, "Condition", 1, 40);
	if (!CONDITION_IDS.has(condition)) throw new Error("Choose a condition");
	const photoAction = body.photoAction === "set" || body.photoAction === "clear" ? body.photoAction : "keep";
	const photo = photoAction === "set" || !withPhotoAction ? photoOrNull(body.photo) : null;
	if ((photoAction === "set" || !withPhotoAction) && body.photo) photoOrNull(body.photo);
	return {
		title: reqText(body.title, "Title", 3, 80),
		description: reqText(body.description, "Description", 10, 2e3),
		price: priceOf(body.price),
		category,
		condition,
		area: reqText(body.area, "Pickup area", 2, 60),
		photo: withPhotoAction ? photo : photoOrNull(body.photo),
		photoAction
	};
}
var createListing_createServerFn_handler = createServerRpc({
	id: "1b019c0c4b1988e0ed8ce7d03c10671e3f9a421b6b2d88e2d40cc192883baa61",
	name: "createListing",
	filename: "src/lib/market.functions.ts"
}, (opts) => createListing.__executeServer(opts));
var createListing = createServerFn({ method: "POST" }).validator((data) => listingInput(data, false)).middleware([authMiddleware]).handler(createListing_createServerFn_handler, async ({ context, data }) => {
	const row = (await (await requireMember(context.userId))`
      insert into listings (seller_id, title, description, price, category, condition, area, photo)
      values (
        ${context.userId}, ${data.title}, ${data.description}, ${data.price},
        ${data.category}, ${data.condition}, ${data.area}, ${data.photo}
      )
      returning id
    `)[0];
	if (!row) throw new Error("Could not post that");
	return { id: row.id };
});
var updateListing_createServerFn_handler = createServerRpc({
	id: "3999ef162b72775a957788ca60ad22f8a3d5d96416844602ce3029045f8aae06",
	name: "updateListing",
	filename: "src/lib/market.functions.ts"
}, (opts) => updateListing.__executeServer(opts));
var updateListing = createServerFn({ method: "POST" }).validator((data) => {
	return {
		id: idOf(asObject(data).id),
		...listingInput(data, true)
	};
}).middleware([authMiddleware]).handler(updateListing_createServerFn_handler, async ({ context, data }) => {
	const rows = await (await requireMember(context.userId))`
      update listings
      set title = ${data.title},
          description = ${data.description},
          price = ${data.price},
          category = ${data.category},
          condition = ${data.condition},
          area = ${data.area},
          photo = case
            when ${data.photoAction} = 'keep' then photo
            when ${data.photoAction} = 'clear' then null
            else ${data.photo}
          end
      where id = ${data.id} and seller_id = ${context.userId}
      returning id
    `;
	if (!rows[0]) throw new Error("You can only edit your own posts");
	return { id: rows[0].id };
});
var setListingStatus_createServerFn_handler = createServerRpc({
	id: "b3b9725a65a3b00c3f8458b22a884040ae6b3670d700e3d780512ac98cce5d5c",
	name: "setListingStatus",
	filename: "src/lib/market.functions.ts"
}, (opts) => setListingStatus.__executeServer(opts));
var setListingStatus = createServerFn({ method: "POST" }).validator((data) => {
	const body = asObject(data);
	const status = body.status === "sold" ? "sold" : body.status === "available" ? "available" : "";
	if (!status) throw new Error("Choose available or sold");
	return {
		id: idOf(body.id),
		status
	};
}).middleware([authMiddleware]).handler(setListingStatus_createServerFn_handler, async ({ context, data }) => {
	const sql = await requireMember(context.userId);
	if (!(await sql`
      update listings set status = ${data.status}
      where id = ${data.id} and seller_id = ${context.userId}
      returning id
    `)[0]) throw new Error("You can only update your own posts");
	if (data.status === "sold") await sql`
        update meetups set status = 'declined'
        where listing_id = ${data.id} and seller_id = ${context.userId} and status = 'open'
      `;
	else await sql`
        update meetups set status = 'cancelled'
        where listing_id = ${data.id} and seller_id = ${context.userId} and status = 'accepted'
      `;
	return { ok: true };
});
var deleteListing_createServerFn_handler = createServerRpc({
	id: "b990a953ff7d82c2d3e09828ee652cc9e8352dab69831888ed1f9546bf84495b",
	name: "deleteListing",
	filename: "src/lib/market.functions.ts"
}, (opts) => deleteListing.__executeServer(opts));
var deleteListing = createServerFn({ method: "POST" }).validator((data) => {
	return { id: idOf(asObject(data).id) };
}).middleware([authMiddleware]).handler(deleteListing_createServerFn_handler, async ({ context, data }) => {
	if (!(await (await requireMember(context.userId))`
      delete from listings where id = ${data.id} and seller_id = ${context.userId} returning id
    `)[0]) throw new Error("You can only remove your own posts");
	return { ok: true };
});
var requestMeetup_createServerFn_handler = createServerRpc({
	id: "4c2ef10e11a009927575d324d9d326a4a9a2fdfb590ccc9d471a1490753c123c",
	name: "requestMeetup",
	filename: "src/lib/market.functions.ts"
}, (opts) => requestMeetup.__executeServer(opts));
var requestMeetup = createServerFn({ method: "POST" }).validator((data) => {
	const body = asObject(data);
	return {
		listingId: idOf(body.listingId),
		message: reqText(body.message, "A note", 2, 500),
		place: reqText(body.place, "A meeting place", 2, 120),
		whenNote: reqText(body.whenNote, "A time", 2, 120)
	};
}).middleware([authMiddleware]).handler(requestMeetup_createServerFn_handler, async ({ context, data }) => {
	const sql = await requireMember(context.userId);
	const listing = (await sql`
      select seller_id, status from listings where id = ${data.listingId} limit 1
    `)[0];
	if (!listing) throw new Error("That post is gone");
	if (listing.seller_id === context.userId) throw new Error("That's your own post");
	if (listing.status === "sold") throw new Error("That's already gone");
	if ((await sql`
      select id from meetups
      where listing_id = ${data.listingId}
        and buyer_id = ${context.userId}
        and status in ('open', 'accepted')
      limit 1
    `)[0]) throw new Error("You already asked to meet about this");
	const row = (await sql`
      insert into meetups (listing_id, buyer_id, seller_id, message, place, when_note)
      values (
        ${data.listingId}, ${context.userId}, ${listing.seller_id},
        ${data.message}, ${data.place}, ${data.whenNote}
      )
      returning id
    `)[0];
	if (!row) throw new Error("Could not send that");
	return { id: row.id };
});
var respondMeetup_createServerFn_handler = createServerRpc({
	id: "3bb2b77cac1668df11a4094e5630f59bf5898c4fe93bb52afb89130d92b5040a",
	name: "respondMeetup",
	filename: "src/lib/market.functions.ts"
}, (opts) => respondMeetup.__executeServer(opts));
var respondMeetup = createServerFn({ method: "POST" }).validator((data) => {
	const body = asObject(data);
	const status = body.status === "accepted" || body.status === "declined" ? body.status : "";
	if (!status) throw new Error("Accept or decline");
	return {
		id: idOf(body.id),
		status
	};
}).middleware([authMiddleware]).handler(respondMeetup_createServerFn_handler, async ({ context, data }) => {
	const sql = await requireMember(context.userId);
	const row = (await sql`
      update meetups set status = ${data.status}
      where id = ${data.id} and seller_id = ${context.userId} and status = 'open'
      returning id, listing_id as "listingId"
    `)[0];
	if (!row) throw new Error("That request is no longer waiting");
	if (data.status === "accepted") await sql`
        update listings set status = 'holding'
        where id = ${row.listingId} and seller_id = ${context.userId} and status = 'available'
      `;
	return { ok: true };
});
var cancelMeetup_createServerFn_handler = createServerRpc({
	id: "6056c9849e9bf1742f59a7d687232a82a2e4cedc86dd877e9eb9265b64ded7d5",
	name: "cancelMeetup",
	filename: "src/lib/market.functions.ts"
}, (opts) => cancelMeetup.__executeServer(opts));
var cancelMeetup = createServerFn({ method: "POST" }).validator((data) => {
	return { id: idOf(asObject(data).id) };
}).middleware([authMiddleware]).handler(cancelMeetup_createServerFn_handler, async ({ context, data }) => {
	const sql = await requireMember(context.userId);
	const row = (await sql`
      update meetups set status = 'cancelled'
      where id = ${data.id} and buyer_id = ${context.userId} and status in ('open', 'accepted')
      returning listing_id as "listingId"
    `)[0];
	if (!row) throw new Error("That meetup can no longer be cancelled");
	const still = await sql`
      select count(*)::int as n from meetups
      where listing_id = ${row.listingId} and status = 'accepted'
    `;
	if (Number(still[0]?.n ?? 0) === 0) await sql`
        update listings set status = 'available'
        where id = ${row.listingId} and status = 'holding'
      `;
	return { ok: true };
});
var listMeetups_createServerFn_handler = createServerRpc({
	id: "af81fcdd9251e4d088dc9ada0409658fbe4948c38eb9255aa1c15098061d0089",
	name: "listMeetups",
	filename: "src/lib/market.functions.ts"
}, (opts) => listMeetups.__executeServer(opts));
var listMeetups = createServerFn({ method: "GET" }).middleware([authMiddleware]).handler(listMeetups_createServerFn_handler, async ({ context }) => {
	return (await (await requireMember(context.userId))`
      select
        m.id,
        m.listing_id as "listingId",
        l.title as "listingTitle",
        l.status as "listingStatus",
        l.price as "listingPrice",
        bp.display_name as "buyerName",
        sp.display_name as "sellerName",
        m.message, m.place, m.when_note as "whenNote", m.status,
        to_char(m.created_at at time zone 'UTC', 'YYYY-MM-DD"T"HH24:MI:SS"Z"') as "createdAt",
        case when m.seller_id = ${context.userId} then 'seller' else 'buyer' end as role
      from meetups m
      join listings l on l.id = m.listing_id
      join profiles bp on bp.user_id = m.buyer_id
      join profiles sp on sp.user_id = m.seller_id
      where m.buyer_id = ${context.userId} or m.seller_id = ${context.userId}
      order by m.created_at desc
      limit 100
    `).map(toMeetup);
});
var listMine_createServerFn_handler = createServerRpc({
	id: "f7b287f85e872ae0b448d8b8273c0734711391b9bcf87f18eedb233b9dbf6b57",
	name: "listMine",
	filename: "src/lib/market.functions.ts"
}, (opts) => listMine.__executeServer(opts));
var listMine = createServerFn({ method: "GET" }).middleware([authMiddleware]).handler(listMine_createServerFn_handler, async ({ context }) => {
	return (await (await requireMember(context.userId))`
      select
        l.id, l.title, l.price, l.category, l.condition, l.area, l.status, l.photo,
        to_char(l.created_at at time zone 'UTC', 'YYYY-MM-DD"T"HH24:MI:SS"Z"') as "createdAt",
        p.display_name as "sellerName",
        true as mine
      from listings l
      join profiles p on p.user_id = l.seller_id
      where l.seller_id = ${context.userId}
      order by l.created_at desc
    `).map(toCard);
});
//#endregion
export { cancelMeetup_createServerFn_handler, createListing_createServerFn_handler, deleteListing_createServerFn_handler, getListing_createServerFn_handler, getMe_createServerFn_handler, listListings_createServerFn_handler, listMeetups_createServerFn_handler, listMine_createServerFn_handler, requestMeetup_createServerFn_handler, respondMeetup_createServerFn_handler, saveProfile_createServerFn_handler, setListingStatus_createServerFn_handler, updateListing_createServerFn_handler };
