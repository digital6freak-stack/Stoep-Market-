import { o as __toESM } from "../_runtime.mjs";
import { Z as require_react, b as Link, w as require_jsx_runtime, x as Navigate } from "../_libs/@tanstack/react-router+[...].mjs";
import { n as CONDITIONS, o as emptyBoard, s as errorText, t as CATEGORIES } from "./market-BYMNOAra.mjs";
import { C as useMember, f as fieldClass, i as Frame, m as listListings, n as Button, o as Opening, s as Shell, t as Alert } from "./ui-BhtY2CpM.mjs";
import { n as ListingCardView } from "./listing-card-C3MFOFWY.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/routes-D09CSPBd.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
function Home() {
	const state = useMember();
	if (state.pending) return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Opening, {});
	if (state.signedOut || state.failed === "Unauthorized") return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Landing, {});
	if (state.failed || !state.me) return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Opening, {
		message: state.failed ?? "Could not open the market",
		onRetry: state.refresh
	});
	if (!state.me.profile) return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Navigate, { to: "/join" });
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Shell, {
		me: state.me,
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Board, {})
	});
}
function Landing() {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Frame, { children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "grid items-center gap-10 md:grid-cols-[minmax(0,1.1fr)_minmax(0,0.9fr)]",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "rise text-sm font-medium tracking-wide text-clay uppercase",
				children: "Neighbourhood market"
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
				className: "rise rise-2 display-bold mt-3 text-4xl text-ink md:text-6xl",
				children: "Second-hand, from the step outside."
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "rise rise-3 mt-4 max-w-xl text-pretty text-lg text-muted",
				children: "Register once. Post what you're finished with. Search what the street is letting go of. Meet nearby and pay cash — Stoep never sits in the middle of the money."
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "mt-6",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
					to: "/login",
					className: "inline-flex min-h-11 items-center justify-center rounded-full bg-clay px-5 text-sm font-medium text-clay-ink",
					children: "Register to join"
				})
			})
		] }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("ol", {
			className: "space-y-3",
			children: [
				[
					"1",
					"Take a stall",
					"Your name and the area you can meet in. Buyers and sellers are the same members."
				],
				[
					"2",
					"Put it out, or hunt",
					"Furniture, kids' things, the kettle you replaced. Prices in rands, including free."
				],
				[
					"3",
					"Meet in public",
					"Agree a place and a time. Hand it over yourself. No delivery, no checkout."
				]
			].map(([n, title, copy], index) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("li", {
				className: `lift rise rise-${index + 1} rounded-card border border-line bg-card p-4`,
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "display text-clay",
						children: n
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
						className: "display mt-1 text-2xl text-ink",
						children: title
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "mt-1 text-pretty text-sm text-muted",
						children: copy
					})
				]
			}, n))
		})]
	}) });
}
function Board() {
	const [draft, setDraft] = (0, import_react.useState)({
		q: "",
		area: "",
		max: "",
		condition: ""
	});
	const [filters, setFilters] = (0, import_react.useState)(emptyBoard);
	const [rows, setRows] = (0, import_react.useState)(null);
	const [error, setError] = (0, import_react.useState)(null);
	(0, import_react.useEffect)(() => {
		let live = true;
		listListings({ data: filters }).then((next) => {
			if (!live) return;
			setRows(next);
			setError(null);
		}).catch((err) => {
			if (!live) return;
			setError(errorText(err));
			setRows([]);
		});
		return () => {
			live = false;
		};
	}, [filters]);
	const filtering = Boolean(filters.q || filters.area || filters.category || filters.condition || filters.includeSold || filters.maxPrice >= 0);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "space-y-5",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "flex flex-wrap items-end justify-between gap-3",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
					className: "display-bold text-4xl text-ink",
					children: "On the stoep"
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "mt-1 text-sm text-muted",
					children: "Newest first. Cash in person, in rands."
				})] }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
					to: "/sell",
					className: "inline-flex min-h-11 items-center rounded-full bg-clay px-5 text-sm font-medium text-clay-ink",
					children: "Put something out"
				})]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("form", {
				className: "space-y-3",
				onSubmit: (event) => {
					event.preventDefault();
					const max = draft.max.trim();
					setFilters((current) => ({
						...current,
						q: draft.q.trim(),
						area: draft.area.trim(),
						condition: draft.condition,
						maxPrice: max === "" ? -1 : Number(max)
					}));
				},
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "flex gap-2",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
							className: fieldClass,
							value: draft.q,
							placeholder: "Search a kettle, a desk, a name…",
							"aria-label": "Search posts",
							onChange: (event) => setDraft({
								...draft,
								q: event.target.value
							})
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
							type: "submit",
							className: "shrink-0",
							children: "Search"
						})]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "-mx-4 flex gap-2 overflow-x-auto px-4 pb-1",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Chip, {
							active: filters.category === "",
							onClick: () => setFilters((current) => ({
								...current,
								category: ""
							})),
							children: "All"
						}), CATEGORIES.map((item) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Chip, {
							active: filters.category === item.id,
							onClick: () => setFilters((current) => ({
								...current,
								category: item.id
							})),
							children: item.label
						}, item.id))]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("details", {
						className: "rounded-2xl border border-line bg-card px-4 py-3",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("summary", {
								className: "cursor-pointer text-sm font-medium text-ink",
								children: "Area, condition, price"
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "mt-3 grid gap-3 sm:grid-cols-3",
								children: [
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
										className: fieldClass,
										value: draft.area,
										placeholder: "Area",
										"aria-label": "Area",
										onChange: (event) => setDraft({
											...draft,
											area: event.target.value
										})
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("select", {
										className: fieldClass,
										value: draft.condition,
										"aria-label": "Condition",
										onChange: (event) => setDraft({
											...draft,
											condition: event.target.value
										}),
										children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
											value: "",
											children: "Any condition"
										}), CONDITIONS.map((item) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
											value: item.id,
											children: item.label
										}, item.id))]
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
										className: `${fieldClass} tabular-nums`,
										inputMode: "numeric",
										value: draft.max,
										placeholder: "Max rands",
										"aria-label": "Maximum price in rands",
										onChange: (event) => setDraft({
											...draft,
											max: event.target.value.replace(/[^\d]/g, "")
										})
									})
								]
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
								className: "mt-3 flex min-h-11 items-center gap-2 text-sm text-ink",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
									type: "checkbox",
									checked: filters.includeSold,
									onChange: (event) => setFilters((current) => ({
										...current,
										includeSold: event.target.checked
									}))
								}), "Show things that have already gone"]
							})
						]
					})
				]
			}),
			error ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Alert, { children: error }) : null,
			rows === null ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "text-sm text-muted",
				children: "Checking what's out…"
			}) : rows.length === 0 ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "rounded-card border border-dashed border-line bg-card px-5 py-10 text-center",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
						className: "display text-3xl text-ink",
						children: filtering ? "Nothing matches" : "The stoep is clear"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "mx-auto mt-2 max-w-md text-pretty text-sm text-muted",
						children: filtering ? "Try a wider search, or clear the filters." : "Be the first on your street to put something out."
					}),
					filtering ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
						variant: "line",
						className: "mt-4",
						onClick: () => {
							setDraft({
								q: "",
								area: "",
								max: "",
								condition: ""
							});
							setFilters(emptyBoard);
						},
						children: "Clear filters"
					}) : null
				]
			}) : /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "text-sm text-muted tabular-nums",
				children: rows.length === 24 ? "Latest 24 posts" : `${rows.length} ${rows.length === 1 ? "post" : "posts"}`
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("ul", {
				className: "grid gap-4 sm:grid-cols-2 lg:grid-cols-3",
				children: rows.map((listing) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("li", {
					className: "min-w-0",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ListingCardView, { listing })
				}, listing.id))
			})] })
		]
	});
}
function Chip({ active, children, onClick }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
		type: "button",
		onClick,
		className: `min-h-11 shrink-0 rounded-full px-4 text-sm font-medium ${active ? "bg-ink text-paper" : "bg-card text-ink border border-line"}`,
		children
	});
}
//#endregion
export { Home as component };
